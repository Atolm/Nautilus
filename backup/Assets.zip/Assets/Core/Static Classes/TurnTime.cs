﻿using UnityEngine;
using System.Collections;

public static class TurnTime {
	public static float deltaTime;
	public static bool timePassed;
}
