﻿using UnityEngine;
using System.Collections;

public class GDroid : GEntity {
	//NA
	
	protected override void Start () {
		base.Start();
	}
	
	// Update is called once per frame
	protected override void Update () {
	}
}
